﻿namespace SoftUni.Configurations
{
    public static class SoftUniDBConfug
    {
        public static string ConnectionString = "Server=.;Database=SoftUni;User Id=sa;Password=Endemole132!;";
    }
}
