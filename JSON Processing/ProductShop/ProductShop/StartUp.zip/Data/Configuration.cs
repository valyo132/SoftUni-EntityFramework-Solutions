﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=.;Database=ProductShop;User Id=sa;Password=Endemole132!;TrustServerCertificate=true;";
    }
}
