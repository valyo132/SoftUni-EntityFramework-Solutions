﻿namespace MusicHub.Data.Configurations
{
    public static class Config
    {
        public static string connectionString = "Server=.;Database=MusicHub;User Id=sa;Password=Endemole132!;TrustServerCertificate=true;";
    }
}
